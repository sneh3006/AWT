var number=123;
var string="Hello";
var boolean=true;
function add(a,b){
    return a+b;
}
console.log(`The Firt variable is number ${number} and its type is ${typeof(number)}`);
console.log(`The Second variable is string ${string} and its type is ${typeof(string)}`);
console.log(`The Third variable is boolean ${boolean} and its type is ${typeof(boolean)}`);

console.log(` function in javaScript returns this  ${add(1,2)} and its type is ${typeof(add)}`);